#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL2_gfxPrimitives.h>
#include <iostream>

int main( int argc, char* args[] ) {
	SDL_Window* window = NULL;
	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_VIDEO);
	IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG);
	TTF_Init();
	Mix_Init(MIX_INIT_OGG | MIX_INIT_MP3);
	 
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {  
		printf("SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
	}

	Mix_Music *music = NULL;
	
	// Load and play a music
	if ((music = Mix_LoadMUS("ErikMcClure-SolarNoise.ogg")) == NULL) {
		std::cout << "Mix_LoadMUS: " << Mix_GetError() << "\n";
	}
	
	if (Mix_PlayMusic(music, -1) == -1) {
		std::cout << "Mix_PlayMusic: " << Mix_GetError() << "\n";
	}


	window = SDL_CreateWindow( "SDL Text", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, SDL_WINDOW_SHOWN );
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);


	// Load surfaces
	SDL_Surface* kappa = NULL;
	SDL_Surface* nyancat = NULL;

	if ((kappa = IMG_Load("kappa.png")) == NULL) {
		std::cout << "IMG_Load: " << IMG_GetError() << "\n";
	}
	
	if ((nyancat = IMG_Load("nyan-cat.jpg")) == NULL) {
		std::cout << "IMG_Load: " << IMG_GetError() << "\n";
	}

	// Positions textures
	SDL_Rect posKappa{ 600, 10, kappa->w, kappa->h };
	SDL_Rect posNyanCat{ 0, 0, nyancat->w, nyancat->h };

	// Load texture from surfaces
	SDL_Texture *texKappa = SDL_CreateTextureFromSurface(renderer, kappa);
	SDL_Texture *texNyanCat = SDL_CreateTextureFromSurface(renderer, nyancat);
	
	// Free surfaces
	SDL_FreeSurface(kappa);
	SDL_FreeSurface(nyancat);

	// Load font 
	TTF_Font *font = NULL;

	if ((font = TTF_OpenFont("trebuc.ttf", 30)) == NULL) {
		std::cout << "TTF_OpenFont: " << TTF_GetError() << "\n";
	}

	SDL_Surface *txt = TTF_RenderText_Blended(font, "Hello World!", SDL_Color{ 255, 255, 255 });
	SDL_Rect posText{ 200, 500, txt->w, txt->h };
	SDL_Texture *texText = SDL_CreateTextureFromSurface(renderer, txt);
	SDL_FreeSurface(txt);

	while (true) {
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break;
			}
		}		

		SDL_RenderClear(renderer);

		SDL_RenderCopy(renderer, texNyanCat, NULL, &posNyanCat);
		SDL_RenderCopy(renderer, texKappa, NULL, &posKappa);
		SDL_RenderCopy(renderer, texText, NULL, &posText);

		// Draw a box in red
		SDL_Point posRect{ 30, 100 };
		SDL_Point sizeRect{ 50, 50 };
		boxRGBA(renderer, posRect.x, posRect.y, posRect.x + sizeRect.x, posRect.y + sizeRect.y, 255, 0, 0, 255);
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

		SDL_RenderPresent(renderer);
	}

	TTF_CloseFont(font);
	Mix_FreeMusic(music);
	SDL_DestroyTexture(texKappa);
	SDL_DestroyTexture(texNyanCat);
	SDL_DestroyTexture(texText);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);

	Mix_Quit();
	TTF_Quit();
	IMG_Quit();
	SDL_Quit();

	return 0;
}